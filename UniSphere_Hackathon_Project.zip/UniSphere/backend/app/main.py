from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, ForeignKey, Text, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker, Session, relationship
from pydantic import BaseModel, Field
from passlib.context import CryptContext
from jose import jwt, JWTError
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional
import os, csv, io, json, secrets, hashlib

ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
UPLOAD_DIR = DATA_DIR / "uploads"
DATA_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{(DATA_DIR / 'unisphere.db').as_posix()}")
connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
SECRET_KEY = os.getenv("UNISPHERE_SECRET", "dev-only-change-this-secret-before-deployment")
ADMIN_PASSWORD = os.getenv("UNISPHERE_ADMIN_PASSWORD", "Hope@50")
ADMIN_ID = os.getenv("UNISPHERE_ADMIN_ID", "admin")
ALGORITHM = "HS256"

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    login_id = Column(String(80), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), nullable=False)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)

class Student(Base):
    __tablename__ = "students"
    id = Column(Integer, primary_key=True)
    student_id = Column(String(40), unique=True, index=True, nullable=False)
    name = Column(String(120), nullable=False)
    department = Column(String(100), default="CSE")
    year = Column(Integer, default=3)
    section = Column(String(10), default="A")
    email = Column(String(150), default="")
    phone = Column(String(30), default="")
    photo = Column(String(500), default="")
    tenth = Column(Float, default=89)
    twelfth = Column(Float, default=91.9)
    cgpa = Column(Float, default=8.0)
    attendance = Column(Float, default=80)
    internal_marks = Column(Float, default=60)
    backlogs = Column(Integer, default=0)
    lms_score = Column(Float, default=70)
    engagement = Column(Float, default=50)
    skills = Column(Float, default=60)
    coding = Column(Float, default=55)
    aptitude = Column(Float, default=55)
    mock_interview = Column(Float, default=50)
    placement_readiness = Column(Float, default=55)
    assignments_done = Column(Float, default=70)
    notes = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class AttendanceRecord(Base):
    __tablename__ = "attendance_records"
    id = Column(Integer, primary_key=True)
    student_id = Column(String(40), index=True)
    subject = Column(String(100))
    date = Column(String(20))
    status = Column(String(20), default="present")
    marked_by = Column(String(80), default="faculty")

class Mark(Base):
    __tablename__ = "marks"
    id = Column(Integer, primary_key=True)
    student_id = Column(String(40), index=True)
    subject = Column(String(100))
    assessment = Column(String(100), default="Internal 1")
    score = Column(Float, default=0)
    max_score = Column(Float, default=100)
    updated_by = Column(String(80), default="faculty")
    updated_at = Column(DateTime, default=datetime.utcnow)

class Message(Base):
    __tablename__ = "messages"
    id = Column(Integer, primary_key=True)
    student_id = Column(String(40), index=True)
    sender_id = Column(String(80))
    recipient_role = Column(String(20), default="student")
    subject = Column(String(200))
    body = Column(Text)
    kind = Column(String(30), default="message")
    status = Column(String(30), default="unread")
    reply = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class Resource(Base):
    __tablename__ = "resources"
    id = Column(Integer, primary_key=True)
    title = Column(String(200))
    subject = Column(String(100), default="General")
    filename = Column(String(255))
    stored_name = Column(String(255))
    uploaded_by = Column(String(80))
    created_at = Column(DateTime, default=datetime.utcnow)

class Intervention(Base):
    __tablename__ = "interventions"
    id = Column(Integer, primary_key=True)
    student_id = Column(String(40), index=True)
    title = Column(String(200))
    action = Column(Text)
    owner = Column(String(80), default="faculty")
    due_date = Column(String(20), default="")
    status = Column(String(30), default="pending")
    remarks = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class Feedback(Base):
    __tablename__ = "feedback"
    id = Column(Integer, primary_key=True)
    student_id = Column(String(40))
    faculty_name = Column(String(120))
    message = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True)
    actor = Column(String(80))
    action = Column(String(150))
    detail = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class Setting(Base):
    __tablename__ = "settings"
    key = Column(String(80), primary_key=True)
    value = Column(String(1000))

Base.metadata.create_all(bind=engine)

def db_session():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def hash_password(password: str) -> str:
    return pwd_context.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    return pwd_context.verify(password, hashed)

def audit(db, actor, action, detail=""):
    db.add(AuditLog(actor=actor, action=action, detail=detail))
    db.commit()

def create_token(login_id, role):
    return jwt.encode({"sub": login_id, "role": role, "exp": datetime.utcnow()+timedelta(hours=10)}, SECRET_KEY, algorithm=ALGORITHM)

def current_user(authorization: Optional[str] = Header(None), db: Session = Depends(db_session)):
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(401, "Please log in.")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        login_id, role = payload.get("sub"), payload.get("role")
    except JWTError:
        raise HTTPException(401, "Session expired. Please log in again.")
    user = db.query(User).filter(User.login_id == login_id, User.active == True).first()
    if not user or user.role != role:
        raise HTTPException(401, "Account is unavailable.")
    return {"login_id": login_id, "role": role}

def require_roles(*roles):
    def checker(user=Depends(current_user)):
        if user["role"] not in roles:
            raise HTTPException(403, "You do not have permission to perform this action.")
        return user
    return checker

def student_dict(s, db=None):
    score = success_score(s)
    risk, reasons = risk_assessment(s)
    return {
        "id": s.id, "student_id": s.student_id, "name": s.name, "department": s.department,
        "year": s.year, "section": s.section, "email": s.email, "phone": s.phone,
        "photo": s.photo, "tenth": s.tenth, "twelfth": s.twelfth, "cgpa": s.cgpa,
        "attendance": s.attendance, "internal_marks": s.internal_marks, "backlogs": s.backlogs,
        "lms_score": s.lms_score, "engagement": s.engagement, "skills": s.skills,
        "coding": s.coding, "aptitude": s.aptitude, "mock_interview": s.mock_interview,
        "placement_readiness": s.placement_readiness, "assignments_done": s.assignments_done,
        "success_score": score, "risk": risk, "risk_reasons": reasons,
        "academic_risk": "High" if s.attendance < 65 or s.internal_marks < 40 or s.backlogs >= 3 else ("Medium" if s.attendance < 75 or s.internal_marks < 55 or s.backlogs >= 1 else "Low"),
        "placement_risk": "High" if s.placement_readiness < 45 else ("Medium" if s.placement_readiness < 65 else "Low"),
    }

def success_score(s):
    # Transparent, configurable baseline; values are normalized to 0-100.
    weights = {"academic": .30, "attendance": .20, "lms": .15, "engagement": .10, "skills": .10, "placement": .15}
    return round(
        max(0, min(100, (s.cgpa / 10) * 100)) * weights["academic"] +
        max(0, min(100, s.attendance)) * weights["attendance"] +
        max(0, min(100, (s.lms_score * .65 + s.assignments_done * .35))) * weights["lms"] +
        max(0, min(100, s.engagement)) * weights["engagement"] +
        max(0, min(100, s.skills)) * weights["skills"] +
        max(0, min(100, s.placement_readiness)) * weights["placement"], 1)

def risk_assessment(s):
    score = success_score(s)
    reasons = []
    if s.attendance < 75: reasons.append(f"Attendance is {s.attendance:.0f}%, below the 75% monitoring threshold.")
    if s.internal_marks < 50: reasons.append(f"Internal marks are {s.internal_marks:.0f}/100, indicating an academic support need.")
    if s.backlogs >= 2: reasons.append(f"There are {s.backlogs} active backlogs.")
    if s.assignments_done < 60: reasons.append(f"Assignment completion is {s.assignments_done:.0f}%.")
    if s.placement_readiness < 50: reasons.append(f"Placement readiness is {s.placement_readiness:.0f}/100.")
    if score < 50 or s.attendance < 55 or s.internal_marks < 35 or s.backlogs >= 3:
        risk = "High"
    elif score < 70 or s.attendance < 75 or s.internal_marks < 50 or s.backlogs >= 1:
        risk = "Medium"
    else:
        risk = "Low"
    if not reasons: reasons.append("No critical indicators crossed the current configured thresholds.")
    return risk, reasons

def get_student_for_user(db, user):
    if user["role"] == "student":
        return db.query(Student).filter(Student.student_id == user["login_id"]).first()
    return None

app = FastAPI(title="UniSphere API", version="1.0.0", description="Student analytics, explainable risk and intervention platform")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class LoginIn(BaseModel):
    login_id: str
    password: str
    role: str
class CreateUserIn(BaseModel):
    login_id: str
    password: str = Field(min_length=8)
    role: str
    name: str = ""
    department: str = "CSE"
    year: int = 3
    section: str = "A"
    email: str = ""
    phone: str = ""
class MarkIn(BaseModel):
    student_id: str
    subject: str
    assessment: str = "Internal 1"
    score: float = Field(ge=0)
    max_score: float = Field(gt=0, le=1000)
class AttendanceIn(BaseModel):
    student_id: str
    subject: str
    date: str
    status: str
class MessageIn(BaseModel):
    student_id: str
    subject: str
    body: str
    kind: str = "message"
class ReplyIn(BaseModel):
    reply: str
class InterventionIn(BaseModel):
    student_id: str
    title: str
    action: str
    due_date: str = ""
class StatusIn(BaseModel):
    status: str
    remarks: str = ""
class FeedbackIn(BaseModel):
    faculty_name: str
    message: str
class UpdateStudentIn(BaseModel):
    name: Optional[str] = None
    department: Optional[str] = None
    year: Optional[int] = None
    section: Optional[str] = None
    cgpa: Optional[float] = Field(default=None, ge=0, le=10)
    attendance: Optional[float] = Field(default=None, ge=0, le=100)
    internal_marks: Optional[float] = Field(default=None, ge=0, le=100)
    backlogs: Optional[int] = Field(default=None, ge=0, le=30)
    lms_score: Optional[float] = Field(default=None, ge=0, le=100)
    engagement: Optional[float] = Field(default=None, ge=0, le=100)
    skills: Optional[float] = Field(default=None, ge=0, le=100)
    placement_readiness: Optional[float] = Field(default=None, ge=0, le=100)
    assignments_done: Optional[float] = Field(default=None, ge=0, le=100)

def seed_data():
    db = SessionLocal()
    try:
        if not db.query(User).filter(User.login_id == ADMIN_ID).first():
            db.add(User(login_id=ADMIN_ID, password_hash=hash_password(ADMIN_PASSWORD), role="admin"))
        demo_users = [
            ("faculty01", "Faculty@123", "faculty"),
            ("faculty02", "Faculty@123", "faculty"),
            ("STU1001", "Student@123", "student"),
            ("STU1002", "Student@123", "student"),
            ("STU1003", "Student@123", "student"),
            ("STU1004", "Student@123", "student"),
            ("STU1005", "Student@123", "student"),
            ("STU1006", "Student@123", "student"),
        ]
        for login_id, pw, role in demo_users:
            if not db.query(User).filter(User.login_id == login_id).first():
                db.add(User(login_id=login_id, password_hash=hash_password(pw), role=role))
        db.commit()
        demo_students = [
            ("STU1001","Aarav Reddy","CSE",3,"A",8.8,92,82,0,90,78,88,86,84,87,90),
            ("STU1002","Mira Sharma","CSE",3,"A",7.1,62,43,2,54,45,51,42,50,46,58),
            ("STU1003","Ishaan Kumar","CSE",3,"B",9.1,68,78,0,85,60,58,38,61,49,86),
            ("STU1004","Ananya Rao","IT",3,"A",8.0,81,68,1,76,66,73,70,72,69,80),
            ("STU1005","Kabir Das","ECE",2,"A",6.4,57,36,3,42,30,40,34,38,32,45),
            ("STU1006","Zoya Khan","CSE",3,"B",8.6,88,75,0,83,91,81,90,86,88,85),
        ]
        for i, row in enumerate(demo_students):
            sid, name, dept, year, sec, cgpa, att, marks, backlogs, lms, engage, skills, coding, aptitude, mock, placement = row
            st = db.query(Student).filter(Student.student_id == sid).first()
            if not st:
                st = Student(student_id=sid, name=name, department=dept, year=year, section=sec,
                    email=f"{sid.lower()}@demo.unisphere.edu", phone=f"900000000{i+1}", tenth=89+i%6,
                    twelfth=91+i%5, cgpa=cgpa, attendance=att, internal_marks=marks, backlogs=backlogs,
                    lms_score=lms, engagement=engage, skills=skills, coding=coding, aptitude=aptitude,
                    mock_interview=mock, placement_readiness=placement, assignments_done=max(25, min(100, lms-5)))
                db.add(st)
        db.commit()
        if db.query(Mark).count() == 0:
            for st in db.query(Student).all():
                for subject, score in [("Data Structures", st.internal_marks), ("Database Systems", min(100, st.internal_marks+7)), ("Operating Systems", max(0, st.internal_marks-4))]:
                    db.add(Mark(student_id=st.student_id, subject=subject, assessment="Internal 1", score=score, max_score=100, updated_by="seed"))
        if db.query(AttendanceRecord).count() == 0:
            for st in db.query(Student).all():
                for subject in ["Data Structures", "Database Systems", "Operating Systems"]:
                    db.add(AttendanceRecord(student_id=st.student_id, subject=subject, date=datetime.now().strftime("%Y-%m-%d"), status="present" if st.attendance >= 70 else "absent", marked_by="seed"))
        if db.query(Message).count() == 0:
            db.add(Message(student_id="STU1002", sender_id="faculty01", recipient_role="student", subject="Attendance follow-up", body="Your attendance is below the monitoring threshold. Please share any context and meet during office hours.", kind="question"))
            db.add(Message(student_id="STU1005", sender_id="faculty02", recipient_role="student", subject="Remedial work: Data Structures", body="Please complete the linked practice set on arrays and linked lists by Friday.", kind="assignment"))
        db.commit()
    finally:
        db.close()
seed_data()

@app.get("/api/health")
def health():
    return {"status":"ok", "service":"UniSphere API", "database":"connected"}

@app.post("/api/auth/login")
def login(payload: LoginIn, db: Session = Depends(db_session)):
    if payload.role not in ["student","faculty","admin"]:
        raise HTTPException(400, "Choose a valid role.")
    user = db.query(User).filter(User.login_id == payload.login_id, User.role == payload.role, User.active == True).first()
    if not user or not verify_password(payload.password, user.password_hash):
        raise HTTPException(401, "Invalid ID or password.")
    audit(db, user.login_id, "login", user.role)
    return {"access_token": create_token(user.login_id, user.role), "token_type":"bearer", "role":user.role, "login_id":user.login_id}

@app.post("/api/auth/forgot-password")
def forgot_password(payload: dict, db: Session = Depends(db_session)):
    # Development fallback only. Production SMS provider integration is required.
    login_id = str(payload.get("login_id", "")).strip()
    phone = str(payload.get("phone", "")).strip()
    user = db.query(User).filter(User.login_id == login_id, User.role.in_(["student","faculty"]), User.active == True).first()
    if not user:
        return {"message":"If the account details match, recovery instructions will be provided."}
    st = db.query(Student).filter(Student.student_id == login_id).first()
    if user.role == "student" and st and phone and phone != st.phone:
        return {"message":"If the account details match, recovery instructions will be provided."}
    otp = f"{secrets.randbelow(1000000):06d}"
    # Store only a hash, with expiry, in a tiny runtime store for local demo.
    OTP_STORE[login_id] = {"hash": hashlib.sha256(otp.encode()).hexdigest(), "expires": datetime.utcnow()+timedelta(minutes=5)}
    return {"message":"Development mode: OTP generated. Configure an SMS provider before production.", "development_otp": otp}

OTP_STORE = {}
@app.post("/api/auth/reset-password")
def reset_password(payload: dict, db: Session = Depends(db_session)):
    login_id = str(payload.get("login_id","")).strip()
    otp = str(payload.get("otp","")).strip()
    new_password = str(payload.get("new_password",""))
    saved = OTP_STORE.get(login_id)
    if not saved or datetime.utcnow() > saved["expires"] or hashlib.sha256(otp.encode()).hexdigest() != saved["hash"]:
        raise HTTPException(400, "Invalid or expired OTP.")
    if len(new_password) < 8:
        raise HTTPException(400, "Password must contain at least 8 characters.")
    user = db.query(User).filter(User.login_id == login_id, User.role.in_(["student","faculty"])).first()
    if not user: raise HTTPException(404, "Account not found.")
    user.password_hash = hash_password(new_password)
    db.commit()
    OTP_STORE.pop(login_id, None)
    audit(db, login_id, "password_reset", "Completed via OTP")
    return {"message":"Password reset successfully."}

@app.get("/api/me")
def me(user=Depends(current_user)):
    return user

@app.get("/api/students")
def list_students(q: str = "", risk: str = "", department: str = "", user=Depends(require_roles("faculty","admin")), db: Session = Depends(db_session)):
    query = db.query(Student)
    if q: query = query.filter((Student.name.ilike(f"%{q}%")) | (Student.student_id.ilike(f"%{q}%")))
    if department: query = query.filter(Student.department == department)
    students = [student_dict(s) for s in query.order_by(Student.name).all()]
    if risk: students = [s for s in students if s["risk"].lower() == risk.lower()]
    return students

@app.get("/api/students/me")
def my_student(user=Depends(require_roles("student")), db: Session = Depends(db_session)):
    st = db.query(Student).filter(Student.student_id == user["login_id"]).first()
    if not st: raise HTTPException(404, "Student profile not found.")
    return student_dict(st)

@app.get("/api/students/{student_id}")
def get_student(student_id: str, user=Depends(current_user), db: Session = Depends(db_session)):
    if user["role"] == "student" and user["login_id"] != student_id:
        raise HTTPException(403, "You can only view your own profile.")
    st = db.query(Student).filter(Student.student_id == student_id).first()
    if not st: raise HTTPException(404, "Student not found.")
    return student_dict(st)

@app.patch("/api/students/{student_id}")
def update_student(student_id: str, payload: UpdateStudentIn, user=Depends(require_roles("admin","faculty")), db: Session = Depends(db_session)):
    st = db.query(Student).filter(Student.student_id == student_id).first()
    if not st: raise HTTPException(404, "Student not found.")
    for k,v in payload.model_dump(exclude_none=True).items(): setattr(st,k,v)
    db.commit()
    audit(db,user["login_id"],"student_updated",student_id)
    return student_dict(st)

@app.post("/api/admin/users")
def create_user(payload: CreateUserIn, user=Depends(require_roles("admin")), db: Session = Depends(db_session)):
    if payload.role not in ["student","faculty"]: raise HTTPException(400,"Admin can create student or faculty accounts.")
    if db.query(User).filter(User.login_id == payload.login_id).first(): raise HTTPException(409,"ID already exists.")
    db.add(User(login_id=payload.login_id, password_hash=hash_password(payload.password), role=payload.role))
    if payload.role == "student":
        db.add(Student(student_id=payload.login_id, name=payload.name or payload.login_id, department=payload.department,
                       year=payload.year, section=payload.section, email=payload.email, phone=payload.phone))
    db.commit()
    audit(db,user["login_id"],"user_created",f"{payload.role}:{payload.login_id}")
    return {"message":"Account created.","login_id":payload.login_id,"role":payload.role}

@app.patch("/api/admin/users/{login_id}/deactivate")
def deactivate_user(login_id: str, user=Depends(require_roles("admin")), db: Session = Depends(db_session)):
    target = db.query(User).filter(User.login_id == login_id).first()
    if not target: raise HTTPException(404,"Account not found.")
    if target.role == "admin": raise HTTPException(400,"Admin accounts cannot be deactivated here.")
    target.active = False
    db.commit()
    audit(db,user["login_id"],"user_deactivated",login_id)
    return {"message":"Account deactivated."}

@app.get("/api/analytics/overview")
def overview(user=Depends(require_roles("faculty","admin")), db: Session = Depends(db_session)):
    students = db.query(Student).all()
    all_data = [student_dict(s) for s in students]
    dept = {}
    for s in all_data:
        d = dept.setdefault(s["department"], {"department":s["department"],"count":0,"avg_cgpa":0,"attendance":0,"high_risk":0,"placement":0})
        d["count"] += 1; d["avg_cgpa"] += s["cgpa"]; d["attendance"] += s["attendance"]
        d["high_risk"] += int(s["risk"] == "High"); d["placement"] += s["placement_readiness"]
    for d in dept.values():
        n=d["count"]; d["avg_cgpa"]=round(d["avg_cgpa"]/n,2); d["attendance"]=round(d["attendance"]/n,1); d["placement"]=round(d["placement"]/n,1)
    n = len(all_data) or 1
    return {
        "total_students":len(students),"total_faculty":db.query(User).filter(User.role=="faculty",User.active==True).count(),
        "avg_cgpa":round(sum(s.cgpa for s in students)/n,2),"attendance":round(sum(s.attendance for s in students)/n,1),
        "high_risk":sum(s["risk"]=="High" for s in all_data),"medium_risk":sum(s["risk"]=="Medium" for s in all_data),
        "low_risk":sum(s["risk"]=="Low" for s in all_data),
        "placement_rate":round(100*sum(s.placement_readiness>=70 for s in students)/n,1),
        "avg_success_score":round(sum(s["success_score"] for s in all_data)/n,1),
        "departments":list(dept.values()),"segments":segment_students(all_data)
    }

def segment_students(students):
    groups = {
        "High academics · low placement": [],
        "Low attendance · decent marks": [],
        "Academic support needed": [],
        "Placement preparation needed": [],
        "On track": []
    }
    for s in students:
        if s["cgpa"] >= 8 and s["placement_readiness"] < 55: groups["High academics · low placement"].append(s)
        elif s["attendance"] < 70 and s["internal_marks"] >= 60: groups["Low attendance · decent marks"].append(s)
        elif s["academic_risk"] == "High" or s["backlogs"] >= 2: groups["Academic support needed"].append(s)
        elif s["placement_readiness"] < 55: groups["Placement preparation needed"].append(s)
        elif s["risk"] == "Low": groups["On track"].append(s)
    return [{"name":k,"count":len(v),"students":[{"student_id":s["student_id"],"name":s["name"]} for s in v]} for k,v in groups.items()]

@app.get("/api/analytics/segments")
def segments(user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    return segment_students([student_dict(s) for s in db.query(Student).all()])

@app.get("/api/marks")
def get_marks(student_id: str = "", user=Depends(current_user), db: Session=Depends(db_session)):
    if user["role"] == "student": student_id = user["login_id"]
    query = db.query(Mark)
    if student_id: query = query.filter(Mark.student_id == student_id)
    return [{"id":m.id,"student_id":m.student_id,"subject":m.subject,"assessment":m.assessment,"score":m.score,"max_score":m.max_score,"updated_at":m.updated_at.isoformat()} for m in query.order_by(Mark.updated_at.desc()).all()]

@app.post("/api/marks")
def save_mark(payload: MarkIn, user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    if payload.score > payload.max_score: raise HTTPException(400,"Score cannot exceed maximum marks.")
    st=db.query(Student).filter(Student.student_id==payload.student_id).first()
    if not st: raise HTTPException(404,"Student not found.")
    m=Mark(student_id=payload.student_id,subject=payload.subject,assessment=payload.assessment,score=payload.score,max_score=payload.max_score,updated_by=user["login_id"])
    db.add(m); st.internal_marks = round((st.internal_marks + payload.score/payload.max_score*100)/2,1); db.commit()
    audit(db,user["login_id"],"mark_saved",f"{payload.student_id}:{payload.subject}:{payload.score}/{payload.max_score}")
    return {"message":"Marks saved and student analytics refreshed.","mark_id":m.id,"student":student_dict(st)}

@app.get("/api/attendance")
def get_attendance(student_id: str = "", user=Depends(current_user), db: Session=Depends(db_session)):
    if user["role"]=="student": student_id=user["login_id"]
    q=db.query(AttendanceRecord)
    if student_id: q=q.filter(AttendanceRecord.student_id==student_id)
    return [{"id":a.id,"student_id":a.student_id,"subject":a.subject,"date":a.date,"status":a.status} for a in q.order_by(AttendanceRecord.id.desc()).limit(200).all()]

@app.post("/api/attendance")
def mark_attendance(payload: AttendanceIn, user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    if payload.status not in ["present","absent","excused"]: raise HTTPException(400,"Invalid attendance status.")
    st=db.query(Student).filter(Student.student_id==payload.student_id).first()
    if not st: raise HTTPException(404,"Student not found.")
    existing=db.query(AttendanceRecord).filter_by(student_id=payload.student_id,subject=payload.subject,date=payload.date).first()
    if existing: existing.status=payload.status; existing.marked_by=user["login_id"]
    else: db.add(AttendanceRecord(student_id=payload.student_id,subject=payload.subject,date=payload.date,status=payload.status,marked_by=user["login_id"]))
    records=db.query(AttendanceRecord).filter_by(student_id=payload.student_id,subject=payload.subject).all()
    # Update profile attendance using demo records as an additional signal when records exist.
    if records:
        st.attendance=round(100*sum(r.status=="present" for r in records)/len(records),1)
    db.commit(); audit(db,user["login_id"],"attendance_saved",f"{payload.student_id}:{payload.subject}:{payload.status}")
    return {"message":"Attendance saved.","student":student_dict(st)}

@app.get("/api/messages")
def get_messages(student_id: str="", user=Depends(current_user), db: Session=Depends(db_session)):
    if user["role"]=="student": student_id=user["login_id"]
    q=db.query(Message)
    if student_id: q=q.filter(Message.student_id==student_id)
    return [{"id":m.id,"student_id":m.student_id,"sender_id":m.sender_id,"subject":m.subject,"body":m.body,"kind":m.kind,"status":m.status,"reply":m.reply,"created_at":m.created_at.isoformat()} for m in q.order_by(Message.created_at.desc()).all()]

@app.post("/api/messages")
def send_message(payload: MessageIn, user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    if not db.query(Student).filter(Student.student_id==payload.student_id).first(): raise HTTPException(404,"Student not found.")
    m=Message(student_id=payload.student_id,sender_id=user["login_id"],subject=payload.subject,body=payload.body,kind=payload.kind,recipient_role="student")
    db.add(m); db.commit(); audit(db,user["login_id"],"message_sent",payload.student_id)
    return {"message":"Message sent to student inbox.","id":m.id}

@app.post("/api/messages/{message_id}/reply")
def reply_message(message_id: int, payload: ReplyIn, user=Depends(current_user), db: Session=Depends(db_session)):
    m=db.query(Message).filter(Message.id==message_id).first()
    if not m: raise HTTPException(404,"Message not found.")
    if user["role"]=="student" and m.student_id!=user["login_id"]: raise HTTPException(403,"Not your message.")
    if user["role"] not in ["student","faculty","admin"]: raise HTTPException(403,"Not allowed.")
    m.reply=payload.reply; m.status="replied"; db.commit()
    audit(db,user["login_id"],"message_replied",str(message_id))
    return {"message":"Reply saved."}

@app.post("/api/feedback")
def submit_feedback(payload: FeedbackIn, user=Depends(require_roles("student")), db: Session=Depends(db_session)):
    fb=Feedback(student_id=user["login_id"],faculty_name=payload.faculty_name,message=payload.message)
    db.add(fb); db.commit(); audit(db,user["login_id"],"faculty_feedback_submitted",payload.faculty_name)
    return {"message":"Feedback submitted privately to the administration."}

@app.get("/api/admin/feedback")
def list_feedback(user=Depends(require_roles("admin")), db: Session=Depends(db_session)):
    return [{"id":f.id,"student_id":f.student_id,"faculty_name":f.faculty_name,"message":f.message,"created_at":f.created_at.isoformat()} for f in db.query(Feedback).order_by(Feedback.created_at.desc()).all()]

@app.get("/api/interventions")
def get_interventions(student_id: str="", user=Depends(current_user), db: Session=Depends(db_session)):
    if user["role"]=="student": student_id=user["login_id"]
    q=db.query(Intervention)
    if student_id:q=q.filter(Intervention.student_id==student_id)
    return [{"id":i.id,"student_id":i.student_id,"title":i.title,"action":i.action,"owner":i.owner,"due_date":i.due_date,"status":i.status,"remarks":i.remarks} for i in q.order_by(Intervention.created_at.desc()).all()]

@app.post("/api/interventions")
def create_intervention(payload: InterventionIn, user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    if not db.query(Student).filter(Student.student_id==payload.student_id).first(): raise HTTPException(404,"Student not found.")
    i=Intervention(student_id=payload.student_id,title=payload.title,action=payload.action,owner=user["login_id"],due_date=payload.due_date)
    db.add(i); db.commit(); audit(db,user["login_id"],"intervention_created",payload.student_id)
    return {"message":"Intervention scheduled.","id":i.id}

@app.patch("/api/interventions/{intervention_id}")
def update_intervention(intervention_id: int, payload: StatusIn, user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    i=db.query(Intervention).filter(Intervention.id==intervention_id).first()
    if not i: raise HTTPException(404,"Intervention not found.")
    if payload.status not in ["pending","in progress","completed","cancelled"]: raise HTTPException(400,"Invalid status.")
    i.status=payload.status;i.remarks=payload.remarks;db.commit()
    audit(db,user["login_id"],"intervention_updated",str(intervention_id))
    return {"message":"Intervention updated."}

@app.post("/api/resources")
async def upload_resource(title: str, subject: str="General", file: UploadFile=File(...), user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    allowed={".pdf",".txt",".docx",".pptx",".png",".jpg",".jpeg"}
    ext=Path(file.filename or "").suffix.lower()
    if ext not in allowed: raise HTTPException(400,"Allowed file types: PDF, TXT, DOCX, PPTX, PNG, JPG.")
    content=await file.read()
    if len(content)>10*1024*1024: raise HTTPException(413,"Maximum file size is 10 MB.")
    stored=f"{secrets.token_hex(12)}{ext}"
    (UPLOAD_DIR/stored).write_bytes(content)
    r=Resource(title=title,subject=subject,filename=Path(file.filename).name,stored_name=stored,uploaded_by=user["login_id"])
    db.add(r);db.commit();audit(db,user["login_id"],"resource_uploaded",r.filename)
    return {"message":"Resource uploaded.","id":r.id}

@app.get("/api/resources")
def list_resources(user=Depends(current_user), db: Session=Depends(db_session)):
    return [{"id":r.id,"title":r.title,"subject":r.subject,"filename":r.filename,"uploaded_by":r.uploaded_by,"created_at":r.created_at.isoformat()} for r in db.query(Resource).order_by(Resource.created_at.desc()).all()]

@app.get("/api/resources/{resource_id}/download")
def download_resource(resource_id:int,user=Depends(current_user),db:Session=Depends(db_session)):
    r=db.query(Resource).filter(Resource.id==resource_id).first()
    if not r: raise HTTPException(404,"Resource not found.")
    path=UPLOAD_DIR/r.stored_name
    if not path.exists(): raise HTTPException(404,"File is missing.")
    return FileResponse(path,filename=r.filename)

@app.post("/api/import/students")
async def import_students(file: UploadFile=File(...), user=Depends(require_roles("admin")), db: Session=Depends(db_session)):
    name=(file.filename or "").lower()
    raw=await file.read()
    rows=[]
    try:
        if name.endswith(".csv"):
            rows=list(csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))))
        elif name.endswith(".xlsx"):
            from openpyxl import load_workbook
            wb=load_workbook(io.BytesIO(raw),read_only=True,data_only=True)
            ws=wb.active
            values=list(ws.values)
            if values: rows=[dict(zip([str(x).strip() for x in values[0]],r)) for r in values[1:]]
        else: raise HTTPException(400,"Upload a CSV or XLSX file.")
    except HTTPException: raise
    except Exception as e: raise HTTPException(400,f"Could not read file: {e}")
    created=0; updated=0; errors=[]
    for idx,row in enumerate(rows, start=2):
        try:
            sid=str(row.get("student_id") or row.get("Student ID") or row.get("ID") or "").strip()
            namev=str(row.get("name") or row.get("Name") or sid).strip()
            if not sid: raise ValueError("student_id is required")
            st=db.query(Student).filter(Student.student_id==sid).first()
            if not st:
                st=Student(student_id=sid,name=namev)
                db.add(st);created+=1
                if not db.query(User).filter(User.login_id==sid).first():
                    db.add(User(login_id=sid,password_hash=hash_password("ChangeMe123!"),role="student"))
            else: updated+=1
            for field in ["department","year","section","cgpa","attendance","internal_marks","backlogs","lms_score","engagement","skills","placement_readiness","assignments_done","email","phone"]:
                val=row.get(field) if field in row else row.get(field.title())
                if val not in (None,""):
                    if field in ["year","backlogs"]: val=int(float(val))
                    elif field in ["cgpa","attendance","internal_marks","lms_score","engagement","skills","placement_readiness","assignments_done"]: val=float(val)
                    setattr(st,field,val)
        except Exception as e:
            errors.append({"row":idx,"error":str(e)})
    try: db.commit()
    except Exception as e:
        db.rollback(); raise HTTPException(400,f"Import transaction failed: {e}")
    audit(db,user["login_id"],"student_import",f"created={created}, updated={updated}, errors={len(errors)}")
    return {"created":created,"updated":updated,"errors":errors,"total_rows":len(rows),"note":"Imported accounts use temporary password ChangeMe123!; reset/change before use."}

@app.get("/api/reports/students.csv")
def report_students(user=Depends(require_roles("faculty","admin")), db: Session=Depends(db_session)):
    output=io.StringIO()
    writer=csv.writer(output)
    writer.writerow(["Student ID","Name","Department","Year","CGPA","Attendance","Internal Marks","Backlogs","Success Score","Risk","Placement Readiness"])
    for st in db.query(Student).order_by(Student.department,Student.name).all():
        d=student_dict(st)
        writer.writerow([st.student_id,st.name,st.department,st.year,st.cgpa,st.attendance,st.internal_marks,st.backlogs,d["success_score"],d["risk"],st.placement_readiness])
    return StreamingResponse(iter([output.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=unisphere-student-report.csv"})

@app.get("/api/admin/audit")
def audit_logs(user=Depends(require_roles("admin")), db: Session=Depends(db_session)):
    return [{"actor":a.actor,"action":a.action,"detail":a.detail,"created_at":a.created_at.isoformat()} for a in db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(200).all()]

@app.get("/api/admin/settings")
def get_settings(user=Depends(require_roles("admin")), db: Session=Depends(db_session)):
    defaults={"weight_academic":"30","weight_attendance":"20","weight_lms":"15","weight_engagement":"10","weight_skills":"10","weight_placement":"15","medium_threshold":"70","high_threshold":"50"}
    for k,v in defaults.items():
        if not db.query(Setting).filter(Setting.key==k).first(): db.add(Setting(key=k,value=v))
    db.commit()
    return {x.key:x.value for x in db.query(Setting).all()}

@app.put("/api/admin/settings")
def update_settings(payload: dict, user=Depends(require_roles("admin")), db: Session=Depends(db_session)):
    allowed={"weight_academic","weight_attendance","weight_lms","weight_engagement","weight_skills","weight_placement","medium_threshold","high_threshold"}
    for k,v in payload.items():
        if k not in allowed: continue
        try: val=float(v)
        except: raise HTTPException(400,f"Invalid value for {k}")
        if val<0 or val>100: raise HTTPException(400,"Settings must be between 0 and 100.")
        item=db.query(Setting).filter(Setting.key==k).first()
        if not item: item=Setting(key=k,value=str(val));db.add(item)
        else:item.value=str(val)
    db.commit();audit(db,user["login_id"],"settings_updated",json.dumps(payload))
    return {"message":"Settings saved. Note: baseline formula in this version is documented in code; changing weights is saved for configuration review."}

# Serve the bundled single-page frontend.
FRONTEND = ROOT / "frontend"
if FRONTEND.exists():
    app.mount("/", StaticFiles(directory=FRONTEND, html=True), name="frontend")
