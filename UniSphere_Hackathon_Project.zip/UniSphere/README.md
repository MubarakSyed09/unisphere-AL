# UniSphere — AI-Powered Student Analytics & Success Platform

A runnable hackathon prototype for the KPMG in India HacXLerate 2026 challenge. UniSphere combines academic, attendance, LMS, engagement, skills, and placement indicators into a transparent Student Success Score, rule-based risk explanations, student segments, and actionable recommendations.

## What's included

- Three role-specific workspaces: Student, Faculty, Admin
- Launch animation and green/beige glassmorphism UI
- FastAPI backend and persistent SQLAlchemy database
- SQLite by default for simple local setup; PostgreSQL supported through `DATABASE_URL`
- Student Success Score baseline and risk explanations
- Student segmentation
- Marks and attendance entry
- Cross-role inbox and replies
- Intervention tracking
- Learning-resource uploads/downloads
- Student CSV/XLSX import and CSV report export
- Private faculty feedback, admin settings and audit log
- Synthetic demo dataset

## Run locally (Windows)

1. Install Python 3.11 or newer.
2. Open a terminal in this folder.
3. Create and activate a virtual environment:

   ```powershell
   py -m venv .venv
   .\.venv\Scripts\Activate.ps1
   ```

4. Install dependencies:

   ```powershell
   pip install -r backend/requirements.txt
   ```

5. Start the application:

   ```powershell
   uvicorn backend.app.main:app --reload
   ```

6. Open `http://127.0.0.1:8000`.
7. API documentation: `http://127.0.0.1:8000/docs`.

On Linux/macOS, create the virtual environment using `python3 -m venv .venv` and activate with `source .venv/bin/activate`.

The SQLite database is created automatically at `data/unisphere.db`. Demo accounts and sample data are seeded on first run.

## Demo credentials

| Role | Login ID | Password |
|---|---|---|
| Admin | `admin` | `Hope@50` |
| Faculty | `faculty01` | `Faculty@123` |
| Faculty | `faculty02` | `Faculty@123` |
| Student | `STU1001` | `Student@123` |
| Student | `STU1002` | `Student@123` |
| Student | `STU1003` | `Student@123` |
| Student | `STU1004` | `Student@123` |
| Student | `STU1005` | `Student@123` |
| Student | `STU1006` | `Student@123` |

These are synthetic demo accounts. Do not use these credentials for a public deployment.

## Student Success Score

The baseline score is:

- Academic performance: 30% (CGPA normalized to 0–100)
- Attendance: 20%
- LMS and assignment activity: 15% (65% LMS indicator + 35% assignment completion)
- Engagement: 10%
- Technical and soft skills: 10%
- Placement readiness: 15%

Each component is normalized to a 0–100 scale. The displayed score is rounded to one decimal place.

Initial risk bands:
- High: score below 50, or a critical rule such as attendance below 55%, internal marks below 35, or at least three backlogs.
- Medium: score below 70, attendance below 75%, internal marks below 50, or at least one backlog.
- Low: otherwise.

Academic risk and placement risk are also shown separately. These are transparent rule-based assessments, not claims from a trained predictive ML model. Tune thresholds with educators and validate using authorized historical data before making real student decisions.

## Password recovery

Password recovery is a **development-only OTP demonstration**. The endpoint displays an OTP in the response because no SMS provider is configured. Before deployment, integrate an SMS provider, do not return OTPs from the API, add persistent rate limits, and verify the registered phone for faculty as well as students.

## Production configuration

Set environment variables before starting:

- `UNISPHERE_SECRET`: a long random signing secret
- `UNISPHERE_ADMIN_ID`: initial administrator login ID
- `UNISPHERE_ADMIN_PASSWORD`: initial administrator password
- `DATABASE_URL`: PostgreSQL connection string for production

Example (PowerShell, only for the current terminal session):

```powershell
$env:UNISPHERE_SECRET = "replace-with-a-long-random-secret"
$env:UNISPHERE_ADMIN_ID = "admin"
$env:UNISPHERE_ADMIN_PASSWORD = "use-a-unique-strong-password"
$env:DATABASE_URL = "postgresql+psycopg://user:password@host:5432/unisphere"
uvicorn backend.app.main:app --host 0.0.0.0 --port 8000
```

Install a compatible PostgreSQL driver (for example, `psycopg[binary]`) when using PostgreSQL. Use HTTPS, restrict CORS to the deployed frontend domain, configure persistent file storage, and run database migrations/backups as part of deployment.

## Import data

Admin → Import student data. CSV/XLSX supports `student_id` (or `Student ID`) and optional fields:

`name, department, year, section, cgpa, attendance, internal_marks, backlogs, lms_score, engagement, skills, placement_readiness, assignments_done, email, phone`

Imported accounts receive a temporary password `ChangeMe123!`; reset/change it before real use. Use synthetic or institution-authorized data only.

## Important limitations before production

- This is a hackathon-ready prototype foundation, not a certified production student information system.
- The frontend is a lightweight single-page app served by FastAPI to make local setup simple.
- The initial risk engine is rule-based. Historical labeled data and validation are needed before adding a trained model.
- Score weight settings are stored in the admin settings screen; the baseline formula in `backend/app/main.py` must be updated to apply changed weights.
- Demo attendance percentages are seeded indicators; when session records are entered, the profile percentage recalculates from the records available in this prototype. Import a complete attendance history for accurate institutional reporting.
- OTP recovery needs an SMS provider before production.
- File storage is local in this prototype; configure persistent object storage for hosted deployments.
- Configure strict CORS, HTTPS, backups, monitoring, retention rules, and institutional privacy review before using real student data.

## Deployment note

This repository can be hosted as one FastAPI service with persistent storage, or the frontend and backend can be split. For a public deployment, use PostgreSQL and persistent file/object storage. The included SQLite file is local-development data and should not be used as a multi-instance production database.
